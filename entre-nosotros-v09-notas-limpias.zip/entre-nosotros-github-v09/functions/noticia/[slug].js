/**
 * Cloudflare Pages Function: devuelve metadatos sociales por noticia.
 * La aplicación React continúa renderizando la noticia en el navegador.
 * Requiere dataset Sanity público y SANITY_PROJECT_ID como variable de Pages.
 */
const API_VERSION = '2025-02-19'
const MAX_SLUG_LENGTH = 96

function encodeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  })[char])
}

function metaContent(key, value, name = 'property') {
  return `<meta ${name}="${encodeHtml(key)}" content="${encodeHtml(value)}">`
}

async function basePage(request, env) {
  const indexUrl = new URL('/', request.url)
  return env.ASSETS.fetch(new Request(indexUrl.toString(), { method: 'GET' }))
}

export async function onRequestGet({ request, env, params }) {
  const slug = typeof params?.slug === 'string' ? params.slug : ''
  if (!new RegExp(`^[a-z0-9-]{1,${MAX_SLUG_LENGTH}}$`).test(slug)) {
    return new Response('Página no encontrada', { status: 404 })
  }

  const page = await basePage(request, env)
  if (!page.ok || !env.SANITY_PROJECT_ID) return page

  const projectId = String(env.SANITY_PROJECT_ID)
  const dataset = String(env.SANITY_DATASET || 'production')
  if (!/^[a-z0-9-]+$/i.test(projectId) || !/^[a-z0-9_-]+$/i.test(dataset)) return page

  const query = `*[_type == "article" && slug.current == $slug && defined(title) && count(body[_type == "block"]) > 0][0]{title, summary, publishedAt, "image":mainImage.asset->url}`
  const url = new URL(`https://${projectId}.apicdn.sanity.io/v${API_VERSION}/data/query/${dataset}`)
  url.searchParams.set('query', query)
  url.searchParams.set('$slug', JSON.stringify(slug))
  url.searchParams.set('perspective', 'published')

  let article
  try {
    const response = await fetch(url.toString(), { headers: { Accept: 'application/json' } })
    if (!response.ok) return page
    article = (await response.json()).result
  } catch {
    return page // Si Sanity falla, el sitio público no debe caerse.
  }

  // Evita etiquetar borradores o rutas inexistentes como noticias publicadas.
  if (!article?.title) return page

  const canonical = new URL(`/noticia/${slug}`, request.url).toString()
  const title = `${article.title} | Ángeles Barrios está Entre Nosotros`
  const description = String(article.summary || 'Periodismo con sentido regional.').slice(0, 300)
  const image = article.image && /^https:\/\//i.test(article.image) ? article.image : ''
  const tags = [
    `<title>${encodeHtml(title)}</title>`,
    metaContent('description', description, 'name'),
    metaContent('og:type', 'article'),
    metaContent('og:site_name', 'Ángeles Barrios está Entre Nosotros'),
    metaContent('og:locale', 'es_MX'),
    metaContent('og:title', article.title),
    metaContent('og:description', description),
    metaContent('og:url', canonical),
    metaContent('twitter:card', image ? 'summary_large_image' : 'summary', 'name'),
    metaContent('twitter:title', article.title, 'name'),
    metaContent('twitter:description', description, 'name'),
    `<link rel="canonical" href="${encodeHtml(canonical)}">`,
  ]
  if (image) {
    tags.push(metaContent('og:image', image))
    tags.push(metaContent('twitter:image', image, 'name'))
  }
  if (article.publishedAt) tags.push(metaContent('article:published_time', article.publishedAt))

  let html = await page.text()
  // Elimina los metadatos genéricos del index que reemplazamos.
  html = html.replace(/<title>[^<]*<\/title>/i, '')
    .replace(/<meta\s+name="description"[^>]*>/i, '')
    .replace(/<meta\s+property="og:[^"]+"[^>]*>/gi, '')
    .replace(/<meta\s+name="twitter:[^"]+"[^>]*>/gi, '')
  html = html.replace('</head>', `  ${tags.join('\n    ')}\n  </head>`)
  const headers = new Headers(page.headers)
  headers.set('content-type', 'text/html; charset=utf-8')
  headers.set('cache-control', 'public, max-age=0, s-maxage=60')
  headers.delete('content-length')
  return new Response(html, { status: 200, headers })
}
