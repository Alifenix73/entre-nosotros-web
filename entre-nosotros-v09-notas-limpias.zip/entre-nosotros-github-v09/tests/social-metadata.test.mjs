import { test } from 'node:test'
import assert from 'node:assert/strict'
import { onRequestGet } from '../functions/noticia/[slug].js'

const html = '<!doctype html><html><head><title>Periódico</title><meta name="description" content="Base"><meta property="og:title" content="Inicio"><meta name="twitter:card" content="summary"></head><body><div id="root"></div></body></html>'
const base = () => new Response(html, { status: 200, headers: { 'content-type': 'text/html' } })
const env = { SANITY_PROJECT_ID: 'abc123', SANITY_DATASET: 'production', ASSETS: { fetch: async () => base() } }

function context(slug = 'nota-prueba', override = {}) {
  return {
    request: new Request(`https://entrenosotros.org/noticia/${slug}`),
    params: { slug },
    env: { ...env, ...override },
  }
}

test('metadatos sociales de noticia publicada', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => Response.json({ result: {
    title: 'Título sobre Tampico & desarrollo',
    summary: 'Resumen de la noticia',
    image: 'https://cdn.sanity.io/images/abc123/production/a.jpg',
    publishedAt: '2026-10-27T16:00:00Z',
  } })
  try {
    const response = await onRequestGet(context())
    const data = await response.text()
    assert.equal(response.status, 200)
    assert.match(data, /og:title/)
    assert.match(data, /Tampico &amp; desarrollo/)
    assert.match(data, /og:image/)
    assert.match(data, /twitter:card/)
    assert.match(data, /href="https:\/\/entrenosotros.org\/noticia\/nota-prueba"/)
    assert.equal((data.match(/<title>/g) || []).length, 1)
    assert.equal((data.match(/property="og:title"/g) || []).length, 1)
  } finally { globalThis.fetch = originalFetch }
})

test('sin credenciales de Sanity mantiene el SPA', async () => {
  const response = await onRequestGet(context('nota-prueba', { SANITY_PROJECT_ID: '' }))
  assert.equal(await response.text(), html)
})

test('identificadores de URL inválidos no se sirven como noticias', async () => {
  const response = await onRequestGet(context('..'))
  assert.equal(response.status, 404)
})

test('una noticia aún no publicada no recibe metadatos falsos', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => Response.json({ result: null })
  try {
    const response = await onRequestGet(context())
    assert.equal(await response.text(), html)
  } finally { globalThis.fetch = originalFetch }
})
